Dear Editors,

Simple historical rules are hard to beat for peak net-position forecasts: regression improves matched hourly FX loss by 14.8% and 16.6% across periods, but historical rules generally prevail at lower frequencies and stationary controls can produce large short-history regression losses.

We submit “Hard to Beat: Historical Rules versus Conditional Quantile Models for Peak Net-Position Limits” to Journal of Forecasting as a comparative forecasting application. The paper uses a common path-dependent response, completed forward labels, matched historical controls, and joint reporting of scores and breaches. Its empirical contribution concerns when added conditioning helps and when rankings change with the benchmark; the forecasting and scoring methods are established.

Evidence comes from one FX market maker, its daily aggregates and related weekly dealer-position categories. Daily aggregation and retrospective backcasts provide within-record checks rather than independent or prospective replication. Distinct stationary and parameter-switching designs remain separate; the new constant control also generates large losses, leaving the empirical mechanism unidentified. All adverse results, failed cells and unavailable summaries remain reported.

The materials include the manuscript, Online Supplement, title-page template, and [versioned code and saved aggregate results](https://github.com/ByronLi0207/financial-mathematics-paper-20261020/tree/revision-v9). Raw FX observations and private per-issue prediction vectors are excluded. Authors must complete and personally confirm authorship, permissions and the required disclosures before submission.

Sincerely,

[TO BE COMPLETED BY AUTHOR]
